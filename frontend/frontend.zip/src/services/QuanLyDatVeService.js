/* eslint-disable no-useless-constructor */
import { baseService } from "./baseService";
import { ThongTinDatVe } from './../_core/models/ThongTinDatVe';

export class QuanLyDatVeService extends baseService {
    constructor() {
        super();
    }

    layChiTietPhongVe = (maLichChieu) => { 
        return this.get(`/api/QuanLyDatVe/LayDanhSachPhongVe?MaLichChieu=${maLichChieu}`);
    }

    datVe = (thongTinDatVe = new ThongTinDatVe()) => {
        return this.post(`/api/QuanLyDatVe/DatVe`,thongTinDatVe);
    }

    layLichChieu = (id) => {
        return this.get(`/api/laydanhsachlichchieu/${id}`);
    }

    taoLichChieu = (thongTinLichChieu) => {
        return this.post(`/api/laydanhsachlichchieu`,thongTinLichChieu);
    }
}

export const quanLyDatVeService = new QuanLyDatVeService();