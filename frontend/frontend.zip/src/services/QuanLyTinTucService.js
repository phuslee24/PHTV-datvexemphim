/* eslint-disable no-useless-constructor */
import { baseService } from "./baseService";

export class QuanLyTinTucService extends baseService {
    constructor() {
        super();
    }

    layDanhSachTinTuc = (id = '') => {
        if (id != '') {
            return this.get(`/api/laydanhsachtintuc/${id}`);

        } else {
            return this.get(`/api/laydanhsachtintuc`);

        }
    }

    themTinTuc = (formData) => {
        return this.post(`/api/laydanhsachtintuc`, formData);
    }

    capNhatTinTuc = (id,formData) => {
        return this.post(`/api/laydanhsachtintuc/${id}/update`,formData);
    }

    xoaTinTuc = (id) => {
        return this.delete(`/api/laydanhsachtintuc/${id}/delete`);
    }
}

export const quanLyTinTucService = new QuanLyTinTucService();