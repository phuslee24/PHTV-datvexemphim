import { CHUYEN_TAB, CHUYEN_TAB_ACTIVE, DAT_VE, DAT_VE_HOAN_TAT, SET_CHI_TIET_PHONG_VE } from "../constants"

const initialState = {
    chiTietPhongVe: {},
    lichChieu:{},
    danhSachGheDangChon: [],
    danhSachGheKhachDat: [{maGhe:61641},{maGhe:61642}],
    tabActive: '1'
}

export const QuanLyDatVeReducer = (state = initialState, action) => {
    switch (action.type) {

        case SET_CHI_TIET_PHONG_VE:
            state.chiTietPhongVe = action.chiTietPhongVe;
            return { ...state }

        case DAT_VE:
            let danhSachGheCapNhat = [...state.danhSachGheDangChon];
            let index = danhSachGheCapNhat.findIndex(gheDD => gheDD.maGhe === action.gheDuocChon.maGhe);
            if (index != -1) {
                danhSachGheCapNhat.splice(index, 1)
            } else {
                danhSachGheCapNhat.push(action.gheDuocChon)
            }
            state.danhSachGheDangChon = danhSachGheCapNhat
            return { ...state }

        case DAT_VE_HOAN_TAT:
            state.danhSachGheDangChon = [];
            return { ...state }

        case CHUYEN_TAB:
            state.tabActive = '2'
            return { ...state }

        case CHUYEN_TAB_ACTIVE:
            state.tabActive = action.number
            return { ...state }

        default:
            return state
    }
}
