import { GET_CUM_RAP_CHIEU, GET_HE_THONG_RAP_CHIEU } from "../constants"

const initialState = {
    heThongRapChieu: [],
    cumRap: [],
}

export const RapReducer = (state = initialState, action) => {
  switch (action.type) {

  case GET_HE_THONG_RAP_CHIEU:
    state.heThongRapChieu = action.heThongRapChieu;
    return { ...state }

    case GET_CUM_RAP_CHIEU:
    state.cumRap = action.cumRap;
    return { ...state }
  default:
    return state
  }
}
