import { quanLyRapService } from "../../services/QuanLyRapService"
import { SET_CHI_TIET_PHIM, GET_HE_THONG_RAP_CHIEU, GET_CUM_RAP_CHIEU } from "../constants";
import { history } from "../../App";


export const layDanhSachHeThongRapAction = (id = '') => {
    return async dispatch => {
        try {
            const result = await quanLyRapService.layDanhSachHeThongRap(id);
            if(result.status === 200) {
                dispatch({
                    type: GET_HE_THONG_RAP_CHIEU,
                    heThongRapChieu:result.data.content,
                })
            }
            
            console.log('hethongrap',result)
        } catch (error) {
            console.log(error.response?.data)
        }
    }
}

export const themHeThongRapAction = (formData) => {
    return async dispatch => {
        try {
            const result = await quanLyRapService.themHeThongRap(formData);
            alert('Thêm hệ thống rạp thành công');
            history.push('/admin/theatremng');
        } catch (error) {
            alert(error.response.data.message)
        }
    }
}

export const capNhatHeThongRapAction = (id,newUser) => {
    return async (dispatch) => {
        try {
            const result = await quanLyRapService.capNhatTheThongRap(id,newUser);
            dispatch(layDanhSachHeThongRapAction())
            alert('Cập nhật hệ thống rạp thành công')
            history.goBack();
        } catch (error) {
            console.log(error)
        }
    }
}


export const xoaHeThongRapAction = (rap) => {
    return async (dispatch) => {
        try {
            const result = await quanLyRapService.xoaHeThongRap(rap);
            alert('Xóa hệ thống rạp thành công');
            dispatch(layDanhSachHeThongRapAction())
        } catch (error) {
            console.log('error', error);
        }
    }
}


////

export const layDanhSachCumRapAction = (id = '') => {
    return async dispatch => {
        try {
            const result = await quanLyRapService.layDanhSachCumRap(id);
            if(result.status === 200) {
                dispatch({
                    type: GET_CUM_RAP_CHIEU,
                    cumRap:result.data.content,
                })
            }
            
            console.log('cumRap',result)
        } catch (error) {
            console.log(error.response?.data)
        }
    }
}


export const themCumRapAction = (formData) => {
    return async dispatch => {
        try {
            const result = await quanLyRapService.themCumRap(formData);
            alert('Thêm cụm rạp thành công');
            history.push('/admin/theatrechildmng');
        } catch (error) {
            alert(error.response.data.message)
        }
    }
}

export const layChiTietPhimAction = (id) => {
    return async dispatch => {
        try {
            const result = await quanLyRapService.layThongTinLichChieuPhim(id);
            if(result.status === 200) {
                dispatch({
                    type: SET_CHI_TIET_PHIM,
                    movieDetail:result.data.content,
                })
            }
            
        } catch (error) {
            console.log(error.response?.data)
        }
    }
}