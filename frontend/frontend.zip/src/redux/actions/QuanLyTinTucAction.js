import { history } from "../../App";
import { quanLyPhimService } from "../../services/QuanLyPhimService";
import { quanLyTinTucService } from "../../services/QuanLyTinTucService";
import { GET_CHI_TIET_TIN_TUC, GET_TIN_TUC, SET_DANH_SACH_PHIM, SET_THONG_TIN_PHIM } from "../constants";

export const layDanhSachTinTucAction = (id='') => {
    return async (dispatch) => {
        
        try {
            if(id !==''){
                const result = await quanLyTinTucService.layDanhSachTinTuc(id)
                dispatch({
                    type: GET_CHI_TIET_TIN_TUC,
                    detailTinTuc: result.data.content
                })
            } else {
                const result = await quanLyTinTucService.layDanhSachTinTuc()
                dispatch({
                    type: GET_TIN_TUC,
                    arrTinTuc: result.data.content
                })
            }
            
        } catch (error) {
            console.log('error', error);
        }
    }
}

export const themTinTucAction = (formData) => {
    return async (dispatch) => {
        try {
            const result = await quanLyTinTucService.themTinTuc(formData)
            alert('Thêm bài viết thành công');
            history.push('/admin/newsmng');
        } catch (error) {
            console.log('error', error);
        }
    }
}

export const capNhatTinTucAction = (id,formData) => {
    return async (dispatch) => {
        try {
            const result = await quanLyTinTucService.capNhatTinTuc(id,formData)
            alert('Cập nhật bài viết thành công');
            history.push('/admin/newsmng');
        } catch (error) {
            console.log('error', error);
        }
    }
}

export const xoaTinTucAction = (id) => {
    return async (dispatch) => {
        try {
            const result = await quanLyTinTucService.xoaTinTuc(id);
            alert('Xóa tin tức thành công');
            dispatch(layDanhSachTinTucAction())
        } catch (error) {
            console.log('error', error);
        }
    }
}