import { ThongTinDatVe } from "../../_core/models/ThongTinDatVe";
import { quanLyDatVeService } from "../../services/QuanLyDatVeService";
import { CHUYEN_TAB, DAT_VE_HOAN_TAT, DISPLAY_LOADING, HIDE_LOADING, SET_CHI_TIET_PHONG_VE } from "../constants";
import { displayLoadingAction, hideLoadingAction } from './LoadingAction';



export const layChiTietPhongVeAction = (maLichChieu) => {
    return async (dispatch) => {
        try {
            const result = await quanLyDatVeService.layLichChieu(maLichChieu);
            if (result.data.statusCode === 200) {
                dispatch({
                    type: SET_CHI_TIET_PHONG_VE,
                    chiTietPhongVe: result.data.content
                })
            }
        } catch (error) {
            console.log(error)
        }
    }
}

export const taoLichChieuAction = (thongTinLichChieu) => {
    return async (dispatch) => {
        try {
            const result = await quanLyDatVeService.taoLichChieu(thongTinLichChieu);
            if (result.data.statusCode === 200) {
                dispatch({
                    type: SET_CHI_TIET_PHONG_VE,
                    chiTietPhongVe: result.data.content
                })
            }
            console.log('lichchieu',result)
        } catch (error) {
            console.log(error)
        }
    }
}

export const datVeAction = (thongTinDatVe = new ThongTinDatVe()) => {
    return async (dispatch) => {
        try {
            dispatch(displayLoadingAction)

            const result = await quanLyDatVeService.datVe(thongTinDatVe);
            if (result.data.statusCode === 200) {
                dispatch({
                    type: SET_CHI_TIET_PHONG_VE,
                    chiTietPhongVe: result.data.content
                })
            }

            //Goi API load lai so do chon ghe
            await dispatch(layChiTietPhongVeAction(thongTinDatVe.maLichChieu))
            await dispatch({
                type: DAT_VE_HOAN_TAT
            })

            await dispatch(hideLoadingAction)
            dispatch({type:CHUYEN_TAB})
        } catch (error) {
            console.log(error)
        }
    }
}

