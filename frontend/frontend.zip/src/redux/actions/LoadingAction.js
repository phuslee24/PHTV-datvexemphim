
import { DISPLAY_LOADING, HIDE_LOADING } from './../constants';

export const displayLoadingAction = {
    type: DISPLAY_LOADING
}

export const hideLoadingAction = {
    type: HIDE_LOADING
}