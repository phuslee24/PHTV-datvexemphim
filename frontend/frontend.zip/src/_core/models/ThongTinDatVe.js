export class ThongTinDatVe {
    maLichChieu = 0;
    danhSachVe = [];
    constructor() {
        
    }
}