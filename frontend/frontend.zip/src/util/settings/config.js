

// export const DOMAIN = 'https://movieapi.cyberlearn.vn';
export const DOMAIN = 'http://127.0.0.1:8000';
export const TOKEN = 'accessToken';
// export const GROUPID = 'GP00';

export const USER_LOGIN = 'USER_LOGIN';