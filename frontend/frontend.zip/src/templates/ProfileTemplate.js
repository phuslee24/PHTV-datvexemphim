import { Fragment, useEffect, useState } from "react";
import { Route } from "react-router-dom";
import { HomeOutlined,SmileOutlined,HistoryOutlined } from '@ant-design/icons';
import { Breadcrumb, Layout, Menu, theme, Button, Avatar, Popover } from 'antd';
import { NavLink } from "react-router-dom";
import _ from "lodash";
import { useSelector } from "react-redux";
import { TOKEN, USER_LOGIN } from "../util/settings/config";
import { Redirect } from "react-router-dom/cjs/react-router-dom.min";
import { history } from "../App";
const { Header, Content, Sider } = Layout;


function getItem(label, key, icon, children) {
  return {
    key,
    icon,
    children,
    label,
  };
}


const items = [
  getItem('Thông Tin Cá Nhân', '1', <NavLink  className='text-decoration-none' to="/users/profile"><SmileOutlined /></NavLink>),
  getItem('Lịch Sử Mua Vé', '2', <NavLink  className='text-decoration-none' to="/users/ordershistory"><HistoryOutlined /></NavLink>),
];



export const ProfileTemplate = (props) => { //path, exact, Component
  const [collapsed, setCollapsed] = useState(false);
  const {
    token: { colorBgContainer },
  } = theme.useToken();
  const { Component, ...restProps } = props;

  const selectedKeys = ['/users/profile','/users/ordershistory']

  
  
  const selectedKey = (selectedKeys.indexOf(props.path) + 1).toString();


  const { userLogin } = useSelector(state => state.UserReducer)
  useEffect(()=>{
    window.scrollTo(0, 0);
  })

  if (!localStorage.getItem(USER_LOGIN)) {
    alert('Bạn không có quyền truy cập trang này!')
    history.push('/')
  }

  const content = (
    <div style={{width:200}}>
          <Button type="text" href="/users/profile" className='w-full text-left'>Trang Cá Nhân</Button>
          {(userLogin.maLoaiNguoiDung === 'QuanTri') ? <Button type="text" className='w-full text-left' href="/admin/users">Trang Quản Trị</Button> : ''} 
          <Button type="text" href="/home" className='w-full text-left' onClick={()=>{
            localStorage.removeItem(USER_LOGIN)
            localStorage.removeItem(TOKEN)
            window.location.reload()
            }}>Đăng Xuất</Button>
        </div>
  );

  const operations = <Fragment>
    {_.isEmpty(userLogin) ? <Fragment>
      <Button type="text" href="/register" className="text-white">Sign Up</Button>
      <Button type="primary" href="/login" className="font-semibold bg-violet-400">Sign In</Button>
    </Fragment> :
      <div className="d-flex">
        <Button type="link" href="/"><HomeOutlined style={{ fontSize: '24px'}}/></Button>
        <Popover placement="bottomRight" title={userLogin.taiKhoan} content={content} trigger="click">
          <Button className='rounded-full bg-slate-300 p-0 d-flex justify-center items-center w-full h-full' style={{ width: 40, height: 40 }}><Avatar size={40} style={{fontSize:'32px',lineHeight:'27px'}} icon={userLogin.taiKhoan.substr(0, 1)} /></Button>
        </Popover>
      </div>}
  </Fragment>

  


  return <Route {...restProps} render={(propsRoute) => { //props.location, props.history, props.match
    return <Fragment>
      
      <Layout
        style={{
          minHeight: '100vh',
        }}
      >
        
        <Sider collapsible collapsed={collapsed} onCollapse={(value) => setCollapsed(value)}>
          <div className="demo-logo-vertical text-white text-2xl text-center my-10" >Trang Cá Nhân</div>
          <Menu theme="dark" defaultSelectedKeys={selectedKey} mode="inline" items={items} />
          
        </Sider>
        <Layout>
        

          <Header
            style={{
              padding: 0,
              background: colorBgContainer,
              display: 'flex',
              justifyContent: 'end',
              alignItems: 'center',
              paddingRight: '30px'
            }}
          >
            <div>{operations}</div>
          </Header>
          <Content
            style={{
              margin: '0 16px',
            }}
          >

            <Breadcrumb
              style={{
                margin: '16px 0',
              }}
            >
              <Breadcrumb.Item>Trang Cá Nhân</Breadcrumb.Item>
              <Breadcrumb.Item>{selectedKey === '1' ? 'Thông Tin Cá Nhân' : 'Lịch Sử Mua Vé'}</Breadcrumb.Item>
            </Breadcrumb>
            <div
              style={{
                padding: 24,
                minHeight: 360,
                background: colorBgContainer,
              }}
            >
              <Component {...propsRoute} />
            </div>
          </Content>

        </Layout>
      </Layout>


    </Fragment>
  }} />
}