import React from 'react'
import { KetQuaDatVe } from '../../Checkout/Checkout'

export default function OrderHistory() {
  return (
    <div>
      <KetQuaDatVe/>
    </div>
  )
}
