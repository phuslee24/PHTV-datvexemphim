import React, { useEffect, useState } from 'react'
import { Form, Button, Select, DatePicker, InputNumber, Input } from 'antd';
import { quanLyRapService } from '../../../services/QuanLyRapService';
import { useFormik } from 'formik';
import moment from 'moment';
import { quanLyDatVeService } from '../../../services/QuanLyDatVeService';
import { useDispatch, useSelector } from 'react-redux';
import { layDanhSachPhimAction } from '../../../redux/actions/QuanLyPhimAction';
import { themCarouselAction } from '../../../redux/actions/CarouselAction';
import { layDanhSachCumRapAction, layDanhSachHeThongRapAction, themCumRapAction } from '../../../redux/actions/QuanLyRapAction';

export default function AddTheatreChild(props) {
    let { heThongRapChieu } = useSelector(state => state.RapReducer);
    const formik = useFormik({
        initialValues: {
            // maPhim: props.match.params.id,
            tenRap: '',
            diachi: '',
        },
        onSubmit: async (values) => {
            // values.tenPhim = arrMovie.find(film => film.maPhim === values['maPhim']);
            let formData = new FormData();
            for (let key in values) {
                formData.append(key, values[key]);
            }
            // Gọi api gửi các giá trị formdata về backend xử lý
            console.table('formData', [...formData])
            dispatch(themCumRapAction(formData));
        }
    })



    const dispatch = useDispatch();
    useEffect(() => {
        dispatch(layDanhSachHeThongRapAction())
    }, [dispatch])



    // const handleChangeMovie = (value) => {
    //     formik.setFieldValue('maRap', value)
    // }


    const convertSelectHTR = () => {
        return heThongRapChieu?.map((item, index) => {
            return { label: item.tenHeThongRap, value: item.maHeThongRap }
        })
    }

    console.log('heThongRapChieu123',heThongRapChieu)

    let carousel = {};
    if (localStorage.getItem('filmParams')) {
        carousel = JSON.parse(localStorage.getItem('carouselParams'));
    }

    return (
        <div className="container">
            <Form
                name="basic"
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 16 }}
                onSubmitCapture={formik.handleSubmit}


            >
                <h3 className="text-2xl">Thêm Cụm Rạp</h3>
                <Form.Item label="Chọn hệ thống rạp:">
                    <Select name='maRap' options={convertSelectHTR()} placeholder="Chọn hệ thống rạp" />
                </Form.Item>
                <Form.Item label="Tên Rạp">
                    <Input name="tenRap" onChange={formik.handleChange} />
                </Form.Item>
                <Form.Item label="Địa chỉ">
                    <Input name="diachi" onChange={formik.handleChange} />
                </Form.Item>
                <Form.Item label="Chức năng">
                    <Button htmlType="submit">Tạo Cụm Rạp</Button>
                </Form.Item>
            </Form>
        </div>
    )
}