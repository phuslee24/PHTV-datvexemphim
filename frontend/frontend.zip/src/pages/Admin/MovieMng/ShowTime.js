import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Form, Button, Select, DatePicker, InputNumber,TimePicker  } from 'antd';
import { quanLyRapService } from '../../../services/QuanLyRapService';
import { useFormik } from 'formik';
import moment from 'moment';
import { quanLyDatVeService } from '../../../services/QuanLyDatVeService';
import { layDanhSachCumRapAction, layDanhSachHeThongRapAction } from '../../../redux/actions/QuanLyRapAction';
import { taoLichChieuAction } from '../../../redux/actions/QuanLyDatVeAction';

export default function ShowTime(props) {
    let { heThongRapChieu } = useSelector(state => state.RapReducer);
    let { cumRap } = useSelector(state => state.RapReducer);
    let { cumRapChieu} = cumRap.filter(item => item.tenRap == heThongRapChieu.tenHeThongRap)
    const dispatch = useDispatch();
    console.log('cumrap',cumRap);
    console.log('cumRapChieu',cumRapChieu);
    const formik = useFormik({
        initialValues: {
            maPhim: props.match.params.id,
            maRap: '',
            ngayChieu: '',
            gioChieu: '',
            giaVeThuong: '',
            giaVeVip: '',
        },
        onSubmit: (values) => {
            // Tạo đối tượng formdata => Đưa giá trị values từ formik vào formdata
            let formData = new FormData();
            for (let key in values) {
                formData.append(key, values[key]);
            }
            dispatch(taoLichChieuAction(formData));
          }
    })


    const [state, setState] = useState({
        heThongRapChieu: [],
        cumRapChieu: []
    })

    useEffect(() => {
        dispatch(layDanhSachHeThongRapAction())
        dispatch(layDanhSachCumRapAction())
    }, []);

    // const handleChangeHeThongRap = async (value) => {
    //     formik.setFieldValue('heThongRap', value)
    // }

    const handleChangeCumRap = (value) => {
        formik.setFieldValue('maRap', value)
    }


    const onOk = (values) => {
        formik.setFieldValue('ngayChieu', moment(values).format('DD/MM/YYYY'))
    }

    const onChangeDate = (values) => {

        formik.setFieldValue('ngayChieu', moment(values).format('DD/MM/YYYY'))
    }

    const onOkHour = (values) => {
        formik.setFieldValue('gioChieu', moment(values).format('hh:mm:ss'))
    }

    const onChangeHour = (values) => {

        formik.setFieldValue('gioChieu', moment(values).format('hh:mm:ss'))
    }

    const handleChangeInputNumber = (name) => {
        return (value) => {
          formik.setFieldValue(name, value);
        }
      }

    const convertSelectHTR = () => {
        // state.heThongRapChieu?.map((htr, index) => ({ label: htr.tenHeThongRap, value: htr.tenHeThongRap }))
        return heThongRapChieu?.map((htr, index) => {
            return { label: htr.tenHeThongRap, value: htr.maHeThongRap }
        })
    }

    let film = {};
    if (localStorage.getItem('filmParams')) {
        film = JSON.parse(localStorage.getItem('filmParams'));
    }

    return (
        <div className="container">
            <Form
                name="basic"
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 16 }}
                onSubmitCapture={formik.handleSubmit}


            >
                <h3 className="text-2xl">Tạo lịch chiếu - {film.tenPhim}</h3>
                <img src={film.hinhAnh} alt='...' width={200} height={100} />
                <Form.Item label="Hệ thống rạp">
                    <Select options={convertSelectHTR()} placeholder="Chọn hệ thống rạp" />
                </Form.Item>
                <Form.Item label="Cụm rạp">
                    <Select options={cumRap?.map((cumRap, index) => ({ label: cumRap.tenRap, value: cumRap.maRap }))} onChange={handleChangeCumRap} placeholder="Chọn cụm rạp" />
                </Form.Item>
                <Form.Item label="Ngày chiếu">
                    <DatePicker format="DD/MM/YYYY" onChange={onChangeDate} onOk={onOk} />
                </Form.Item>

                <Form.Item label="Giờ chiếu">
                    <TimePicker format="hh:mm:ss" onChange={onChangeHour} onOk={onOkHour} />
                </Form.Item>

                <Form.Item label="Giá vé thường">
                    <InputNumber onChange={handleChangeInputNumber('giaVeThuong')} />
                </Form.Item>
                <Form.Item label="Giá vé VIP">
                    <InputNumber onChange={handleChangeInputNumber('giaVeVip')} />
                </Form.Item>
                <Form.Item label="Chức năng">
                    <Button htmlType="submit">Tạo lịch chiếu</Button>
                </Form.Item>
            </Form>
        </div>
    )
}