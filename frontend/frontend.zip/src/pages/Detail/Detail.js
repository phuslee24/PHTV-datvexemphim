import React from 'react'
import './Detail.css'
import { Tabs, Rate } from 'antd';
import moment from 'moment/moment';
import { useDispatch, useSelector } from 'react-redux';
import { useEffect } from 'react';
import { layChiTietPhimAction } from '../../redux/actions/QuanLyRapAction';
import { NavLink } from 'react-router-dom';
const { TabPane } = Tabs;

export default function Detail(props) {

    const { movieDetail } = useSelector(state => state.MovieReducer);
    const dispatch = useDispatch();
    useEffect(() => {
        let { id } = props.match.params;
        dispatch(layChiTietPhimAction(id))
    }, [])
    return (
        <div style={{
            position: 'absolute',
            height: 'auto',
            width: '100%',
        }}
        >
            <div style={{
                backgroundImage: `url(${movieDetail.hinhAnh})`,
                height: 'auto',
                width: '100%',
                filter: 'blur(15px)',
                zIndex: -10,
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
            }}
            ></div>
            <div style={{
                backgroundImage: `url(${movieDetail.hinhAnh})`,
                height: 'auto',
                width: '100%',
                zIndex: -20,
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundSize: 'cover',
                backgroundRepeat: 'no-repeat',
                backgroundPosition: 'center',
            }}
            ></div>
            <div className='row h-full relative z-10 mt-60'>
                <div className='col-4 d-flex justify-end items-center h-full' >
                    <img className='posterphim mr-3' src={movieDetail.hinhAnh} alt={movieDetail.hinhAnh} />

                </div>
                <div className='col-4 d-flex justify-start items-center z-10'>
                    <div className='text-white'>
                        <p>Ngày chiếu: {moment(movieDetail.ngayKhoiChieu).format('DD.MM.YYYY')}</p>
                        <p className='text-4xl'>{movieDetail.tenPhim}</p>
                        <Rate allowHalf value={movieDetail.danhGia / 2} />
                    </div>
                </div>
                <div className='col-4 d-flex justify-start items-center' >
                    <div className={`c100 p${movieDetail.danhGia / 10 * 100} big green`}>
                        <span>{movieDetail.danhGia}/10</span>
                        <div className="slice">
                            <div className="bar" />
                            <div className="fill" />
                        </div>
                    </div>

                </div>
            </div>
            <div className='container' style={{ minHeight: '500px' }}>
                <Tabs defaultActiveKey='1' centered className='text-white mt-20'>
                    <TabPane tab="Lịch chiếu" key="1">
                        <Tabs tabPosition={'left'}>
                            {movieDetail.heThongRapChieu?.map((htr, index) => {
                                return <TabPane tab={<div><img className='rounded-full' src={htr.logo} alt={htr.logo} width={50} />{htr.tenHeThongRap}</div>} key={index}>
                                    {htr.cumRapChieu?.map((cumRap, index) => {
                                        return <div key={index}>
                                            <div className='flex'>
                                                <img src='https://picsum.photos/60' style={{width:60, height:60}} alt='rapChieu'/>
                                                <div className='ml-2 text-white'>
                                                    <h3 className='text-lg'>{cumRap.tenCumRap}</h3>
                                                    <p>{cumRap.diaChi}</p>
                                                </div>

                                            </div>
                                            <div className='grid grid-cols-6'>
                                                {cumRap.lichChieuPhim?.map((lichChieu,index)=>{
                                                    return <NavLink key={index} to={`/checkout/${lichChieu.maLichChieu}`} className='text-green-500'>{moment(lichChieu.ngayChieuGioChieu).format('hh:mm A')}</NavLink>
                                                })}
                                            </div>
                                        </div>
                                    })}
                                </TabPane>
                            })}
                        </Tabs>
                    </TabPane>
                    <TabPane tab="Thông tin" key="2">
                        Thông tin
                    </TabPane>
                    <TabPane tab="Đánh giá" key="3">
                        Đánh giá
                    </TabPane>
                </Tabs>

            </div>

        </div >




    )
}
