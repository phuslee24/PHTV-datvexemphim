import React, { useEffect } from 'react'
import './News.css'
import { useDispatch, useSelector } from 'react-redux';
import { layDanhSachTinTucAction } from './../../redux/actions/QuanLyTinTucAction';
import { Card } from 'antd';

export default function News() {
  const { Meta } = Card;
  const { arrTinTuc } = useSelector(state => state.NewsReducer);
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(layDanhSachTinTucAction())
  }, [])

  console.log('arrTinTuc', arrTinTuc)
  const renderTinTuc = () => {
    return arrTinTuc.map((item, index) => {
      return <Card
        key={index}
        hoverable
        className='d-flex my-3 w-full'
        style={{ height: 180, overflow: 'hidden' }}
        bodyStyle={{width:'100%'}}
        cover={<img alt={item.tieuDe} className='ant-card-cover-customs' src={item.hinhAnh} style={{ width: 350, height: 180, objectFit: 'cover' }} />}
      >
        <div className='d-flex justify-between'>
            <p className='text-danger w-1/3'>{item.tacGia}</p>
            <p className='w-1/3'>{item.theLoai}</p>
          <p className='w-1/3 text-right'>{item.created_at.substr(0, 10)}</p>
        </div>

        <Meta title={item.tieuDe} description={item.noiDungPhu} />
      </Card>

    })
  }
  return (
    <div>
      <div class="header__img-text">
        <h2 class=" text-white heading__text drop-shadow-md">Tin Điện Ảnh</h2>
        <div class="text-white end__text drop-shadow-md">Tin tức điện ảnh Việt Nam & thế giới</div>
      </div>
      <div class="header__bg-dark header__with-img"></div>
      <div className='container'>
        <div className='row'>
          <div className='col-8'>{renderTinTuc()}</div>
          <div className='col-4'>
            <div className="flex flex-col items-center bg-white border border-gray-200 rounded-lg shadow-md md:flex-row w-full my-3">
              <div className="flex flex-col justify-between p-4 leading-normal">
                <h5 className="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">Bài Viết Mới Nhất</h5>
                <p className="mb-3 font-normal text-gray-700 dark:text-gray-400">Here are the biggest enterprise technology acquisitions of 2021 so far, in reverse chronological order.</p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}
