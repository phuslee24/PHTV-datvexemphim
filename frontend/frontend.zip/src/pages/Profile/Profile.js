import React, { useEffect } from 'react';
import {
  Button,
  Typography,
} from 'antd';
import { useDispatch, useSelector } from 'react-redux';
import { layDanhSachNguoiDungAction } from '../../redux/actions/QuanLyNguoiDungAction';
const Profile = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(layDanhSachNguoiDungAction())
  }, [])

  const { profile } = useSelector(state => state.UserReducer);

  return (
    <div >
      <h3 className='mb-5'>Thông tin người dùng: {profile.taiKhoan}</h3>
      <div className='row mx-10'>
        <div className='col-6'>
          <Typography>
            <pre>Tên Đăng Nhập: {profile.taiKhoan}</pre>
          </Typography>
        </div>
        <div className='col-6'>
          <Typography>
            <pre>Email: {profile.email}</pre>
          </Typography>
        </div>
        <div className='col-6'>
          <Typography>
            <pre>Email: {profile.soDt}</pre>
          </Typography>
        </div>
        <div className='col-6'>
          <Typography>
            <pre>Họ Tên: {profile.hoTen}</pre>
          </Typography>
        </div>
        <div className='col-6'>
          <Typography>
            <pre>Loại Tài Khoản: {profile.maLoaiNguoiDung}</pre>
          </Typography>
        </div>
        <div className='col-6'>
        <Button href={`/users/edit/${profile.taiKhoan}`} className='btn-primary bg-primary mt-3 px-5' type='primary' onClick={() => {
            localStorage.setItem('userParams', JSON.stringify(profile));
          }}>Thay đổi thông tin</Button>
        </div>
      </div>
    </div>
  );
};

export default Profile;